# 🌌 Portfolio 3D — Website giới thiệu bản thân

Website portfolio cá nhân hiện đại với nền 3D hạt sáng, hiệu ứng cuộn mượt, chế độ sáng/tối, trình phát nhạc nền và đầy đủ các chức năng hoạt động thật.

**Công nghệ:** React 19 · TypeScript · Tailwind CSS 4 · Three.js (React Three Fiber) · Vite

> ⚠️ Toàn bộ thông tin cá nhân hiện tại là **dữ liệu mẫu tiếng Việt**. Hãy thay bằng thông tin thật của bạn trước khi công khai.

---

## 🚀 Cài đặt & chạy

```bash
npm install     # cài đặt phụ thuộc
npm run dev     # chạy máy chủ phát triển (http://localhost:5173)
npm run build   # build bản production vào thư mục dist/
npm run preview # xem thử bản build
```

---

## 📁 Cấu trúc thư mục

```
portfolio/
├── index.html                  # Tiêu đề + meta description (sửa tên của bạn ở đây)
├── .env.example                # Mẫu biến môi trường (endpoint gửi email)
├── public/
│   └── avatar.png              # Ảnh đại diện (ảnh minh họa AI — thay bằng ảnh của bạn)
└── src/
    ├── config/
    │   └── profile.ts          # ⭐ TỆP CẤU HÌNH DUY NHẤT — mọi thông tin cá nhân ở đây
    ├── context/
    │   └── SettingsContext.tsx # Theme sáng/tối + bật/tắt hiệu ứng (ghi nhớ lựa chọn)
    └── components/
        ├── Background3D.tsx    # Nền 3D hạt sáng (lazy-load, fallback tĩnh)
        ├── Navbar.tsx          # Điều hướng + menu mobile + đánh dấu mục đang xem
        ├── Hero.tsx            # Trang chủ, hiệu ứng gõ chữ, nút CV & mạng xã hội
        ├── About.tsx           # Giới thiệu + thẻ thông tin + số liệu
        ├── Skills.tsx          # Kỹ năng theo nhóm
        ├── Projects.tsx        # Lưới dự án + bộ lọc + hộp thoại chi tiết + tilt 3D
        ├── Journey.tsx         # Timeline hành trình
        ├── Contact.tsx         # Form liên hệ (validate tiếng Việt, mailto dự phòng)
        ├── Footer.tsx          # Chân trang, năm tự động, nút về đầu trang
        ├── MusicPlayer.tsx     # Trình phát nhạc nền
        ├── Reveal.tsx          # Hiệu ứng xuất hiện khi cuộn
        └── Icons.tsx           # Icon SVG inline
```

---

## ✏️ Thay thông tin cá nhân

Mở **`src/config/profile.ts`** — mọi thứ đều ở đây:

| Mục | Trường cần sửa |
|---|---|
| Họ tên, nghề nghiệp, giới thiệu | `name`, `role`, `typingPhrases`, `shortBio`, `story` |
| Email, địa điểm | `email`, `location` |
| Mạng xã hội | mảng `socials` (label, url, icon) |
| Thẻ thông tin & số liệu | `infoCards`, `stats` (đặt `isSample: false` **chỉ khi** là số liệu thật) |
| Kỹ năng | `skillGroups` (nhãn kinh nghiệm `levelLabel` là tùy chọn) |
| Dự án | `projects` + `projectCategories` (nút Demo/Mã nguồn chỉ hiện khi URL bắt đầu bằng `http`) |
| Hành trình | `timeline` — thêm/sửa/xóa phần tử tùy ý |

Sau đó sửa **tiêu đề & meta description** trong `index.html` cho khớp tên bạn.

### 🖼️ Thay ảnh đại diện
1. Đặt ảnh của bạn vào `public/` (ví dụ `public/toi.jpg`).
2. Sửa `avatar: "/toi.jpg"` trong `profile.ts`.
3. Ảnh `avatar.png` hiện tại là **ảnh minh họa do AI tạo** — nên thay trước khi dùng thật.

### 🖼️ Ảnh dự án
Đặt ảnh vào `public/projects/` rồi điền `image: "/projects/ten-anh.jpg"` cho từng dự án. Chưa có ảnh → thẻ tự dùng nền gradient đẹp mắt.

### 📄 Gắn CV (PDF)
1. Đặt tệp vào `public/` (ví dụ `public/cv-cua-toi.pdf`).
2. Sửa `cvUrl: "/cv-cua-toi.pdf"` trong `profile.ts`.
3. Chưa cấu hình → nút "Tải CV" tự vô hiệu hóa kèm giải thích (không có nút giả).

### 🎵 Thêm nhạc nền
1. Đặt tệp nhạc **có bản quyền hợp lệ** (mp3/ogg) vào `public/` (ví dụ `public/music/lofi.mp3`).
2. Sửa `musicSrc: "/music/lofi.mp3"` trong `profile.ts`.
3. Nhạc **không bao giờ tự phát** — người dùng phải bấm ▶ (đúng chính sách trình duyệt). Âm lượng được ghi nhớ, có fade in/out, mặc định 30%.
4. Chưa cấu hình → trình phát hiển thị trạng thái "chưa cấu hình", không dùng liên kết hỏng.

### ✉️ Kích hoạt gửi email từ form
1. Sao chép `.env.example` thành `.env`.
2. Điền endpoint nhận form, ví dụ [Formspree](https://formspree.io) (miễn phí):
   ```
   VITE_CONTACT_ENDPOINT=https://formspree.io/f/xxxxxxxx
   ```
3. Khởi động lại `npm run dev`.
4. **Chưa cấu hình** → form hiển thị thông báo rõ ràng và cung cấp nút "Gửi bằng ứng dụng email" (mailto). Website **không bao giờ** báo "gửi thành công" giả.
5. Không có khóa bí mật nào nằm trong mã phía trình duyệt — endpoint form là loại công khai (public form endpoint).

---

## 🧩 Những gì BẠN cần bổ sung

| Hạng mục | Trạng thái hiện tại | Cần làm |
|---|---|---|
| Ảnh đại diện | Ảnh minh họa AI | Thay bằng ảnh thật của bạn |
| CV PDF | Chưa có — nút bị vô hiệu hóa | Thêm tệp + sửa `cvUrl` |
| Nhạc nền | Chưa có — hiển thị "chưa cấu hình" | Thêm tệp nhạc có bản quyền + sửa `musicSrc` |
| Gửi email từ form | Chưa có — dùng mailto dự phòng | Tạo `.env` với `VITE_CONTACT_ENDPOINT` |
| Ảnh dự án | Dùng gradient placeholder | Thêm ảnh vào `public/projects/` |
| Liên kết mạng xã hội & dự án | URL mẫu `example.com` | Thay bằng liên kết thật |

---

## 🌐 Đưa website lên GitHub Pages (chạy trên mọi điện thoại, miễn phí)

Dự án đã có sẵn file tự động deploy (`.github/workflows/deploy.yml`). Bạn chỉ cần:

### Bước 1 — Tạo kho chứa (repository) trên GitHub
1. Đăng ký / đăng nhập tại [github.com](https://github.com).
2. Bấm nút **New repository** (dấu **+** góc phải trên).
3. Đặt tên, ví dụ: `portfolio` → bấm **Create repository** (để chế độ **Public**).

### Bước 2 — Đưa code lên (chạy trong thư mục dự án trên máy tính)
```bash
git init
git add .
git commit -m "Website portfolio dau tien"
git branch -M main
git remote add origin https://github.com/TEN-CUA-BAN/portfolio.git
git push -u origin main
```
> Thay `TEN-CUA-BAN` bằng tên tài khoản GitHub của bạn. Lần đầu push, GitHub sẽ yêu cầu đăng nhập.
>
> 💡 Không rành lệnh git? Tải **GitHub Desktop** (desktop.github.com) rồi kéo-thả thư mục vào là xong.

### Bước 3 — Bật GitHub Pages
1. Vào repo trên GitHub → **Settings** → **Pages** (menu bên trái).
2. Mục **Build and deployment** → **Source** → chọn **GitHub Actions**.
3. Vào tab **Actions**, chờ workflow "Deploy lên GitHub Pages" chạy xong (dấu ✅, khoảng 1–2 phút).

### Bước 4 — Mở trên điện thoại 📱
Website của bạn sẽ có địa chỉ:
```
https://TEN-CUA-BAN.github.io/portfolio/
```
Mở link này trên bất kỳ điện thoại / máy tính nào. Từ nay, **mỗi lần push code mới lên nhánh `main`, website tự cập nhật**.

> 🎁 Mẹo: trên điện thoại, mở link bằng Chrome/Safari → menu → **"Thêm vào màn hình chính"** để có icon như một ứng dụng.

### Cách khác (cũng miễn phí, kéo-thả không cần git)
- **Netlify** ([netlify.com](https://app.netlify.com/drop)): chạy `npm run build` rồi kéo-thả thư mục `dist/` vào trang Drop — có link ngay lập tức.
- **Vercel** ([vercel.com](https://vercel.com)): kết nối repo GitHub, tự nhận diện Vite, bấm Deploy.

---

## ♿ Trợ năng & hiệu năng

- Tôn trọng `prefers-reduced-motion`; có nút ✨ bật/tắt hiệu ứng riêng (ghi nhớ lựa chọn).
- Nền 3D: lazy-load, `aria-hidden`, không chặn thao tác, giới hạn pixel ratio 1.5, giảm mật độ hạt trên mobile, tạm dừng render khi tab ẩn, fallback nền tĩnh khi không có WebGL.
- Nội dung không bao giờ bị ẩn vĩnh viễn nếu JS/animation lỗi (hiệu ứng reveal có cơ chế dự phòng).
- Menu mobile và hộp thoại dự án: đóng bằng Escape, quản lý focus, hỗ trợ bàn phím đầy đủ.
- Form có nhãn, thông báo lỗi tiếng Việt gắn `aria-describedby`, trạng thái gửi dùng `aria-live`.
