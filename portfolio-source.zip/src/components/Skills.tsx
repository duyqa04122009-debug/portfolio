import { profile } from "../config/profile";
import Reveal from "./Reveal";

export default function Skills() {
  return (
    <section id="skills" className="mx-auto max-w-6xl px-4 py-24">
      <Reveal>
        <h2 className="text-center text-3xl font-bold sm:text-4xl">
          Kỹ <span className="text-gradient">năng</span>
        </h2>
        <p className="mx-auto mt-3 max-w-xl text-center text-[var(--text-muted)]">
          Những công nghệ, công cụ và kỹ năng mềm tôi sử dụng thường xuyên.
        </p>
      </Reveal>

      <div className="mt-12 grid gap-6 md:grid-cols-3">
        {profile.skillGroups.map((group, gi) => (
          <Reveal key={group.title} delay={gi * 100}>
            <div className="glass h-full rounded-2xl p-6">
              <h3 className="text-lg font-semibold">{group.title}</h3>
              <ul className="mt-4 space-y-3">
                {group.items.map((skill) => (
                  <li
                    key={skill.name}
                    className="flex items-center justify-between gap-3 rounded-xl border border-transparent bg-[var(--bg-soft)]/60 px-4 py-3 transition-all hover:-translate-y-0.5 hover:border-[var(--card-border)]"
                  >
                    <span className="flex items-center gap-3">
                      <span className="text-lg" aria-hidden="true">
                        {skill.icon}
                      </span>
                      <span className="text-sm font-medium">{skill.name}</span>
                    </span>
                    {skill.levelLabel && (
                      <span className="shrink-0 rounded-full bg-[var(--primary)]/15 px-2.5 py-1 text-xs font-medium text-[var(--primary-soft)]">
                        {skill.levelLabel}
                      </span>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal delay={200}>
        <p className="mt-6 text-center text-xs text-[var(--text-muted)]">
          Nhãn kinh nghiệm mang tính tự đánh giá, chỉnh sửa dễ dàng trong{" "}
          <code>src/config/profile.ts</code>.
        </p>
      </Reveal>
    </section>
  );
}
