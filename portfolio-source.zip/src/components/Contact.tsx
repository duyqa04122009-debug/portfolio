import { useState, type FormEvent } from "react";
import { profile } from "../config/profile";
import Reveal from "./Reveal";
import { SocialIcon } from "./Icons";

type Status = "idle" | "sending" | "success" | "error";

const ENDPOINT = import.meta.env.VITE_CONTACT_ENDPOINT as string | undefined;

interface Errors {
  name?: string;
  email?: string;
  message?: string;
}

export default function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<Status>("idle");
  const [copied, setCopied] = useState(false);

  const hasEndpoint = Boolean(ENDPOINT && /^https?:\/\//.test(ENDPOINT));

  function validate(): boolean {
    const next: Errors = {};
    if (!name.trim()) next.name = "Vui lòng nhập họ tên.";
    if (!email.trim()) {
      next.email = "Vui lòng nhập email.";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      next.email = "Email không hợp lệ, ví dụ: ten@example.com.";
    }
    if (!message.trim()) {
      next.message = "Vui lòng nhập nội dung.";
    } else if (message.trim().length < 10) {
      next.message = "Nội dung quá ngắn (tối thiểu 10 ký tự).";
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!validate()) return;

    if (!hasEndpoint) return; // nút submit không hiển thị khi chưa cấu hình

    setStatus("sending");
    try {
      const res = await fetch(ENDPOINT!, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ name, email, message }),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setStatus("success");
      setName("");
      setEmail("");
      setMessage("");
    } catch {
      setStatus("error");
    }
  }

  function openMailApp() {
    if (!validate()) return;
    const subject = encodeURIComponent(`Liên hệ từ ${name} (portfolio)`);
    const body = encodeURIComponent(`${message}\n\n— ${name} (${email})`);
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
  }

  async function copyEmail() {
    try {
      await navigator.clipboard.writeText(profile.email);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      // Dự phòng khi Clipboard API bị chặn
      window.prompt("Sao chép thủ công địa chỉ email:", profile.email);
    }
  }

  const inputClass = (hasError: boolean) =>
    `focus-ring w-full rounded-xl border bg-[var(--bg-soft)]/70 px-4 py-3 text-sm placeholder:text-[var(--text-muted)]/60 ${
      hasError ? "border-red-400" : "border-[var(--card-border)]"
    }`;

  return (
    <section id="contact" className="mx-auto max-w-5xl px-4 py-24">
      <Reveal>
        <h2 className="text-center text-3xl font-bold sm:text-4xl">
          Liên <span className="text-gradient">hệ</span>
        </h2>
        <p className="mx-auto mt-3 max-w-xl text-center text-[var(--text-muted)]">
          Bạn có dự án thú vị hoặc muốn trò chuyện? Hãy gửi tin nhắn cho tôi.
        </p>
      </Reveal>

      <div className="mt-12 grid gap-8 md:grid-cols-5">
        {/* Thông tin liên hệ */}
        <Reveal className="md:col-span-2">
          <div className="glass h-full rounded-2xl p-6">
            <h3 className="font-semibold">Thông tin liên hệ</h3>
            <div className="mt-4 space-y-3 text-sm text-[var(--text-muted)]">
              <p className="break-all">
                ✉️ <span className="select-all">{profile.email}</span>
              </p>
              <p>📍 {profile.location}</p>
            </div>
            <button
              type="button"
              onClick={copyEmail}
              className="focus-ring mt-4 rounded-xl border border-[var(--card-border)] px-4 py-2 text-sm font-medium transition-colors hover:border-[var(--accent)] hover:text-[var(--accent)]"
            >
              {copied ? "✅ Đã sao chép!" : "📋 Sao chép email"}
            </button>
            <div aria-live="polite" className="sr-only">
              {copied ? "Đã sao chép địa chỉ email vào bộ nhớ tạm" : ""}
            </div>

            <h4 className="mt-6 text-sm font-semibold uppercase tracking-wide text-[var(--text-muted)]">
              Mạng xã hội
            </h4>
            <ul className="mt-3 flex gap-2">
              {profile.socials.map((s) => (
                <li key={s.label}>
                  <a
                    href={s.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={s.label}
                    title={s.label}
                    className="focus-ring glass flex h-10 w-10 items-center justify-center rounded-full text-[var(--text-muted)] transition-all hover:-translate-y-1 hover:text-[var(--accent)]"
                  >
                    <SocialIcon name={s.icon} />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>

        {/* Form */}
        <Reveal delay={120} className="md:col-span-3">
          <form onSubmit={onSubmit} noValidate className="glass rounded-2xl p-6">
            {!hasEndpoint && (
              <div className="mb-5 rounded-xl border border-amber-400/40 bg-amber-400/10 px-4 py-3 text-sm text-[var(--text-muted)]">
                ℹ️ Dịch vụ gửi email trực tiếp <strong>chưa được cấu hình</strong>{" "}
                (biến <code>VITE_CONTACT_ENDPOINT</code> trong tệp{" "}
                <code>.env</code>). Bạn vẫn có thể gửi tin nhắn bằng ứng dụng
                email của mình qua nút bên dưới.
              </div>
            )}

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="ct-name" className="mb-1.5 block text-sm font-medium">
                  Họ tên <span aria-hidden="true" className="text-red-400">*</span>
                </label>
                <input
                  id="ct-name"
                  name="name"
                  type="text"
                  autoComplete="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Nguyễn Văn A"
                  aria-invalid={Boolean(errors.name)}
                  aria-describedby={errors.name ? "ct-name-err" : undefined}
                  className={inputClass(Boolean(errors.name))}
                />
                {errors.name && (
                  <p id="ct-name-err" role="alert" className="mt-1.5 text-xs text-red-400">
                    {errors.name}
                  </p>
                )}
              </div>
              <div>
                <label htmlFor="ct-email" className="mb-1.5 block text-sm font-medium">
                  Email <span aria-hidden="true" className="text-red-400">*</span>
                </label>
                <input
                  id="ct-email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="ban@example.com"
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? "ct-email-err" : undefined}
                  className={inputClass(Boolean(errors.email))}
                />
                {errors.email && (
                  <p id="ct-email-err" role="alert" className="mt-1.5 text-xs text-red-400">
                    {errors.email}
                  </p>
                )}
              </div>
            </div>

            <div className="mt-4">
              <label htmlFor="ct-message" className="mb-1.5 block text-sm font-medium">
                Nội dung <span aria-hidden="true" className="text-red-400">*</span>
              </label>
              <textarea
                id="ct-message"
                name="message"
                rows={5}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Xin chào, tôi muốn trao đổi về..."
                aria-invalid={Boolean(errors.message)}
                aria-describedby={errors.message ? "ct-message-err" : undefined}
                className={inputClass(Boolean(errors.message))}
              />
              {errors.message && (
                <p id="ct-message-err" role="alert" className="mt-1.5 text-xs text-red-400">
                  {errors.message}
                </p>
              )}
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-3">
              {hasEndpoint && (
                <button
                  type="submit"
                  disabled={status === "sending"}
                  className="focus-ring rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--accent)] px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-[var(--primary)]/25 transition-transform hover:-translate-y-0.5 disabled:cursor-wait disabled:opacity-70"
                >
                  {status === "sending" ? "⏳ Đang gửi..." : "🚀 Gửi tin nhắn"}
                </button>
              )}
              <button
                type="button"
                onClick={openMailApp}
                className="focus-ring glass rounded-xl px-6 py-3 text-sm font-semibold transition-transform hover:-translate-y-0.5"
              >
                ✉️ Gửi bằng ứng dụng email
              </button>
            </div>

            <div aria-live="polite" className="mt-4">
              {status === "success" && (
                <p className="rounded-xl border border-emerald-400/40 bg-emerald-400/10 px-4 py-3 text-sm text-emerald-300">
                  ✅ Gửi thành công! Cảm ơn bạn, tôi sẽ phản hồi sớm nhất có thể.
                </p>
              )}
              {status === "error" && (
                <p className="rounded-xl border border-red-400/40 bg-red-400/10 px-4 py-3 text-sm text-red-300">
                  ❌ Gửi thất bại. Vui lòng thử lại hoặc dùng nút "Gửi bằng ứng
                  dụng email".
                </p>
              )}
            </div>
          </form>
        </Reveal>
      </div>
    </section>
  );
}
