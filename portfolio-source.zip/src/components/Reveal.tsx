import { useEffect, useRef, type ReactNode } from "react";
import { useSettings } from "../context/SettingsContext";

/**
 * Bọc nội dung để tạo hiệu ứng fade + translate khi cuộn vào khung nhìn.
 * An toàn: nếu JS lỗi hoặc IntersectionObserver không có, nội dung vẫn hiển thị.
 */
export default function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const { reducedMotion, effectsOn } = useSettings();

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (reducedMotion || !effectsOn || !("IntersectionObserver" in window)) {
      el.classList.remove("reveal-init");
      return;
    }
    el.classList.add("reveal-init");
    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            window.setTimeout(() => el.classList.add("reveal-show"), delay);
            io.unobserve(el);
          }
        }
      },
      { threshold: 0.12 }
    );
    io.observe(el);
    // Dự phòng: nếu sau 2.5s vẫn chưa hiện (trường hợp hiếm), buộc hiển thị
    const fallback = window.setTimeout(() => el.classList.add("reveal-show"), 2500);
    return () => {
      io.disconnect();
      window.clearTimeout(fallback);
    };
  }, [delay, reducedMotion, effectsOn]);

  return (
    <div ref={ref} className={className}>
      {children}
    </div>
  );
}
