import { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { useSettings } from "../context/SettingsContext";

/** Kiểm tra WebGL khả dụng */
function supportsWebGL(): boolean {
  try {
    const canvas = document.createElement("canvas");
    return !!(
      window.WebGLRenderingContext &&
      (canvas.getContext("webgl2") || canvas.getContext("webgl"))
    );
  } catch {
    return false;
  }
}

/** Đám hạt sáng trôi chậm + thị sai nhẹ theo cuộn và con trỏ */
function Particles({ count, reducedMotion }: { count: number; reducedMotion: boolean }) {
  const points = useRef<THREE.Points>(null);
  const scroll = useRef(0);
  const pointer = useRef({ x: 0, y: 0 });

  const { positions, colors } = useMemo(() => {
    const pos = new Float32Array(count * 3);
    const col = new Float32Array(count * 3);
    const cPrimary = new THREE.Color("#8b7cf7");
    const cAccent = new THREE.Color("#22d3ee");
    const tmp = new THREE.Color();
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 24;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 16;
      pos[i * 3 + 2] = (Math.random() - 0.5) * 12;
      tmp.copy(cPrimary).lerp(cAccent, Math.random());
      col[i * 3] = tmp.r;
      col[i * 3 + 1] = tmp.g;
      col[i * 3 + 2] = tmp.b;
    }
    return { positions: pos, colors: col };
  }, [count]);

  useEffect(() => {
    const onScroll = () => {
      const max = Math.max(
        1,
        document.documentElement.scrollHeight - window.innerHeight
      );
      scroll.current = window.scrollY / max;
    };
    const onPointer = (e: PointerEvent) => {
      pointer.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      pointer.current.y = (e.clientY / window.innerHeight) * 2 - 1;
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("pointermove", onPointer, { passive: true });
    onScroll();
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("pointermove", onPointer);
    };
  }, []);

  useFrame((state, delta) => {
    const p = points.current;
    if (!p) return;
    const t = state.clock.elapsedTime;
    if (!reducedMotion) {
      p.rotation.y = t * 0.02;
      // Quán tính nhẹ (lerp) — không rung giật
      const targetY = scroll.current * 2.2 + pointer.current.y * 0.15;
      const targetX = pointer.current.x * 0.25;
      p.position.y = THREE.MathUtils.damp(p.position.y, targetY, 2, delta);
      p.position.x = THREE.MathUtils.damp(p.position.x, targetX, 2, delta);
    }
  });

  return (
    <points ref={points}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-color" args={[colors, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.055}
        vertexColors
        transparent
        opacity={0.8}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

/** Vài khối icosahedron kính mờ trôi chậm tạo chiều sâu */
function FloatingShapes({ reducedMotion }: { reducedMotion: boolean }) {
  const group = useRef<THREE.Group>(null);
  const shapes = useMemo(
    () =>
      [
        { pos: [-5, 2, -4], scale: 0.9, speed: 0.25 },
        { pos: [5.5, -1.5, -5], scale: 1.3, speed: 0.18 },
        { pos: [2.5, 3, -7], scale: 0.7, speed: 0.3 },
      ] as const,
    []
  );

  useFrame((state) => {
    const g = group.current;
    if (!g || reducedMotion) return;
    const t = state.clock.elapsedTime;
    g.children.forEach((child, i) => {
      const s = shapes[i];
      child.rotation.x = t * s.speed * 0.4;
      child.rotation.y = t * s.speed * 0.6;
      child.position.y = s.pos[1] + Math.sin(t * s.speed + i * 2) * 0.4;
    });
  });

  return (
    <group ref={group}>
      {shapes.map((s, i) => (
        <mesh key={i} position={s.pos as unknown as [number, number, number]} scale={s.scale}>
          <icosahedronGeometry args={[1, 0]} />
          <meshStandardMaterial
            color="#6d5df0"
            transparent
            opacity={0.12}
            wireframe
          />
        </mesh>
      ))}
    </group>
  );
}

/** Tạm dừng render khi tab bị ẩn */
function VisibilityGate() {
  const { invalidate, setFrameloop } = useThree();
  useEffect(() => {
    const onVis = () => {
      setFrameloop(document.hidden ? "never" : "always");
      if (!document.hidden) invalidate();
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [invalidate, setFrameloop]);
  return null;
}

export default function Background3D() {
  const { effectsOn, reducedMotion, theme } = useSettings();
  const [webgl, setWebgl] = useState<boolean | null>(null);
  const isMobile =
    typeof window !== "undefined" && window.innerWidth < 768;

  useEffect(() => {
    setWebgl(supportsWebGL());
  }, []);

  // Nền tĩnh dự phòng: không WebGL, tắt hiệu ứng, hoặc đang kiểm tra
  if (!effectsOn || webgl === false || webgl === null) {
    return (
      <div
        aria-hidden="true"
        className="static-bg fixed inset-0 -z-10"
        data-testid="static-bg"
      />
    );
  }

  return (
    <div aria-hidden="true" className="fixed inset-0 -z-10 pointer-events-none">
      <div className="static-bg absolute inset-0" />
      <Canvas
        camera={{ position: [0, 0, 9], fov: 55 }}
        dpr={[1, 1.5]} /* giới hạn pixel ratio để tiết kiệm pin/GPU */
        gl={{ antialias: false, powerPreference: "low-power", alpha: true }}
        style={{ opacity: theme === "light" ? 0.55 : 1 }}
      >
        <VisibilityGate />
        <ambientLight intensity={0.6} />
        {/* Giảm mật độ hạt trên điện thoại */}
        <Particles count={isMobile ? 350 : 900} reducedMotion={reducedMotion} />
        {!isMobile && <FloatingShapes reducedMotion={reducedMotion} />}
      </Canvas>
    </div>
  );
}
