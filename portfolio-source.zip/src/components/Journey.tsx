import { profile } from "../config/profile";
import Reveal from "./Reveal";

const typeMeta: Record<string, { icon: string; label: string }> = {
  education: { icon: "🎓", label: "Học tập" },
  work: { icon: "💼", label: "Kinh nghiệm" },
  milestone: { icon: "🚀", label: "Cột mốc" },
};

export default function Journey() {
  return (
    <section id="journey" className="mx-auto max-w-4xl px-4 py-24">
      <Reveal>
        <h2 className="text-center text-3xl font-bold sm:text-4xl">
          Hành <span className="text-gradient">trình</span>
        </h2>
        <p className="mx-auto mt-3 max-w-xl text-center text-[var(--text-muted)]">
          Timeline học tập, kinh nghiệm và các cột mốc đáng nhớ (dữ liệu mẫu).
        </p>
      </Reveal>

      <ol className="relative mt-14 space-y-10 border-l-2 border-[var(--card-border)] pl-8 md:ml-6">
        {profile.timeline.map((item, i) => {
          const meta = typeMeta[item.type] ?? typeMeta.milestone;
          return (
            <Reveal key={`${item.time}-${item.title}`} delay={i * 100}>
              <li className="relative">
                <span
                  aria-hidden="true"
                  className="absolute -left-[3.05rem] flex h-9 w-9 items-center justify-center rounded-full border border-[var(--card-border)] bg-[var(--bg-soft)] text-base shadow-lg"
                >
                  {meta.icon}
                </span>
                <div className="glass rounded-2xl p-5 transition-transform hover:-translate-y-1">
                  <div className="flex flex-wrap items-center gap-2 text-sm">
                    <span className="font-semibold text-[var(--accent)]">
                      {item.time}
                    </span>
                    <span className="rounded-full bg-[var(--primary)]/15 px-2.5 py-0.5 text-xs text-[var(--primary-soft)]">
                      {meta.label}
                    </span>
                  </div>
                  <h3 className="mt-2 font-semibold">{item.title}</h3>
                  <p className="text-sm text-[var(--text-muted)]">{item.place}</p>
                  <p className="mt-2 text-sm leading-relaxed text-[var(--text-muted)]">
                    {item.description}
                  </p>
                </div>
              </li>
            </Reveal>
          );
        })}
      </ol>
    </section>
  );
}
