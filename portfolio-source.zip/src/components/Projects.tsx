import { useCallback, useEffect, useRef, useState } from "react";
import { profile, type Project } from "../config/profile";
import Reveal from "./Reveal";
import { useSettings } from "../context/SettingsContext";
import { withBase } from "../lib/paths";

const isValidUrl = (u?: string) => Boolean(u && /^https?:\/\//.test(u));

/** Hiệu ứng nghiêng 3D theo con trỏ — chỉ trên thiết bị có hover + không reduced-motion */
function useTilt(enabled: boolean) {
  const ref = useRef<HTMLDivElement>(null);

  const onMove = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      const el = ref.current;
      if (!el || !enabled) return;
      if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches)
        return;
      const rect = el.getBoundingClientRect();
      const px = (e.clientX - rect.left) / rect.width - 0.5;
      const py = (e.clientY - rect.top) / rect.height - 0.5;
      el.style.transform = `perspective(900px) rotateY(${px * 7}deg) rotateX(${
        -py * 7
      }deg) translateY(-4px)`;
    },
    [enabled]
  );

  const onLeave = useCallback(() => {
    const el = ref.current;
    if (el) el.style.transform = "";
  }, []);

  return { ref, onMove, onLeave };
}

function gradientFor(id: string) {
  const gradients = [
    "linear-gradient(135deg, #6d5df0 0%, #22d3ee 100%)",
    "linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)",
    "linear-gradient(135deg, #0ea5e9 0%, #6d5df0 100%)",
    "linear-gradient(135deg, #06b6d4 0%, #8b7cf7 100%)",
  ];
  let h = 0;
  for (const c of id) h = (h * 31 + c.charCodeAt(0)) % 997;
  return gradients[h % gradients.length];
}

function ProjectCard({
  project,
  onOpen,
}: {
  project: Project;
  onOpen: (p: Project) => void;
}) {
  const { effectsOn, reducedMotion } = useSettings();
  const tilt = useTilt(effectsOn && !reducedMotion);

  return (
    <div
      ref={tilt.ref}
      onPointerMove={tilt.onMove}
      onPointerLeave={tilt.onLeave}
      className="tilt-card glass group h-full overflow-hidden rounded-2xl"
    >
      <button
        type="button"
        onClick={() => onOpen(project)}
        className="focus-ring block h-full w-full cursor-pointer text-left"
        aria-haspopup="dialog"
        aria-label={`Xem chi tiết dự án ${project.title}`}
      >
        <div
          className="flex h-40 items-center justify-center text-5xl"
          style={
            project.image
              ? undefined
              : { background: gradientFor(project.id), opacity: 0.9 }
          }
        >
          {project.image ? (
            <img
              src={withBase(project.image)}
              alt={`Ảnh minh họa dự án ${project.title}`}
              loading="lazy"
              className="h-full w-full object-cover"
            />
          ) : (
            <span aria-hidden="true" className="drop-shadow-lg">
              {project.category === "Thử nghiệm 3D"
                ? "🧊"
                : project.category === "Landing Page"
                ? "🎨"
                : "🖥️"}
            </span>
          )}
        </div>
        <div className="p-5">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-semibold group-hover:text-[var(--accent)]">
              {project.title}
            </h3>
            <span className="shrink-0 rounded-full bg-[var(--primary)]/15 px-2.5 py-1 text-xs text-[var(--primary-soft)]">
              {project.category}
            </span>
          </div>
          <p className="mt-2 text-sm text-[var(--text-muted)]">
            {project.description}
          </p>
          <ul className="mt-3 flex flex-wrap gap-2" aria-label="Công nghệ">
            {project.tech.map((t) => (
              <li
                key={t}
                className="rounded-md border border-[var(--card-border)] px-2 py-0.5 text-xs text-[var(--text-muted)]"
              >
                {t}
              </li>
            ))}
          </ul>
        </div>
      </button>
    </div>
  );
}

function ProjectModal({
  project,
  onClose,
}: {
  project: Project;
  onClose: () => void;
}) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  // Quản lý focus: đưa focus vào hộp thoại, bẫy Tab, đóng bằng Escape
  useEffect(() => {
    const previouslyFocused = document.activeElement as HTMLElement | null;
    closeRef.current?.focus();
    document.body.style.overflow = "hidden";

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "Tab") {
        const focusables = dialogRef.current?.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        if (!focusables || focusables.length === 0) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      previouslyFocused?.focus();
    };
  }, [onClose]);

  const hasDemo = isValidUrl(project.demoUrl);
  const hasSource = isValidUrl(project.sourceUrl);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="project-modal-title"
        className="glass max-h-[85vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-[var(--bg-soft)] p-6 shadow-2xl"
      >
        <div className="flex items-start justify-between gap-4">
          <h3 id="project-modal-title" className="text-xl font-bold">
            {project.title}
          </h3>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            aria-label="Đóng hộp thoại"
            className="focus-ring glass rounded-full p-2 hover:text-[var(--accent)]"
          >
            <svg
              width="18"
              height="18"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              aria-hidden="true"
            >
              <path d="M6 6l12 12M18 6L6 18" />
            </svg>
          </button>
        </div>

        <span className="mt-2 inline-block rounded-full bg-[var(--primary)]/15 px-3 py-1 text-xs text-[var(--primary-soft)]">
          {project.category}
        </span>
        <p className="mt-4 leading-relaxed text-[var(--text-muted)]">
          {project.details}
        </p>

        <h4 className="mt-5 text-sm font-semibold uppercase tracking-wide text-[var(--text-muted)]">
          Công nghệ sử dụng
        </h4>
        <ul className="mt-2 flex flex-wrap gap-2">
          {project.tech.map((t) => (
            <li
              key={t}
              className="rounded-md border border-[var(--card-border)] px-2.5 py-1 text-xs"
            >
              {t}
            </li>
          ))}
        </ul>

        <div className="mt-6 flex flex-wrap gap-3">
          {hasDemo && (
            <a
              href={project.demoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="focus-ring rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--accent)] px-5 py-2.5 text-sm font-semibold text-white"
            >
              🔗 Xem demo
            </a>
          )}
          {hasSource && (
            <a
              href={project.sourceUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="focus-ring glass rounded-xl px-5 py-2.5 text-sm font-semibold"
            >
              📂 Mã nguồn
            </a>
          )}
          {!hasDemo && !hasSource && (
            <p className="text-sm italic text-[var(--text-muted)]">
              Dự án này chưa có liên kết demo hoặc mã nguồn công khai.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

export default function Projects() {
  const [filter, setFilter] = useState("Tất cả");
  const [selected, setSelected] = useState<Project | null>(null);

  const filtered =
    filter === "Tất cả"
      ? profile.projects
      : profile.projects.filter((p) => p.category === filter);

  return (
    <section id="projects" className="mx-auto max-w-6xl px-4 py-24">
      <Reveal>
        <h2 className="text-center text-3xl font-bold sm:text-4xl">
          Dự <span className="text-gradient">án</span>
        </h2>
        <p className="mx-auto mt-3 max-w-xl text-center text-[var(--text-muted)]">
          Một số dự án tiêu biểu (dữ liệu mẫu). Bấm vào thẻ để xem chi tiết.
        </p>
      </Reveal>

      {/* Bộ lọc */}
      <Reveal delay={80}>
        <div
          className="mt-8 flex flex-wrap justify-center gap-2"
          role="group"
          aria-label="Lọc dự án theo danh mục"
        >
          {profile.projectCategories.map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setFilter(cat)}
              aria-pressed={filter === cat}
              className={`focus-ring rounded-full px-4 py-2 text-sm font-medium transition-all ${
                filter === cat
                  ? "bg-gradient-to-r from-[var(--primary)] to-[var(--accent)] text-white shadow-lg shadow-[var(--primary)]/25"
                  : "glass text-[var(--text-muted)] hover:text-[var(--text)]"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </Reveal>

      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((p, i) => (
          <Reveal key={p.id} delay={i * 80}>
            <ProjectCard project={p} onOpen={setSelected} />
          </Reveal>
        ))}
      </div>

      {filtered.length === 0 && (
        <p className="mt-10 text-center text-[var(--text-muted)]">
          Chưa có dự án nào trong danh mục này.
        </p>
      )}

      {selected && (
        <ProjectModal project={selected} onClose={() => setSelected(null)} />
      )}
    </section>
  );
}
