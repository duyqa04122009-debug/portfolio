import { useEffect, useState } from "react";
import { profile } from "../config/profile";
import { SocialIcon } from "./Icons";
import { useSettings } from "../context/SettingsContext";
import { withBase } from "../lib/paths";

/** Hiệu ứng gõ chữ — tôn trọng prefers-reduced-motion */
function useTyping(phrases: string[], enabled: boolean) {
  const [text, setText] = useState(phrases[0] ?? "");
  const [index, setIndex] = useState(0);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (!enabled) {
      setText(phrases[0] ?? "");
      return;
    }
    const current = phrases[index % phrases.length];
    let delay = deleting ? 40 : 85;
    if (!deleting && text === current) delay = 1800; // dừng khi gõ xong
    if (deleting && text === "") delay = 350;

    const t = window.setTimeout(() => {
      if (!deleting && text === current) {
        setDeleting(true);
      } else if (deleting && text === "") {
        setDeleting(false);
        setIndex((i) => (i + 1) % phrases.length);
      } else {
        setText(
          deleting
            ? current.slice(0, text.length - 1)
            : current.slice(0, text.length + 1)
        );
      }
    }, delay);
    return () => window.clearTimeout(t);
  }, [text, deleting, index, phrases, enabled]);

  return text;
}

export default function Hero() {
  const { reducedMotion } = useSettings();
  const typed = useTyping(profile.typingPhrases, !reducedMotion);
  const hasCV = Boolean(profile.cvUrl);

  return (
    <section
      id="home"
      className="relative flex min-h-screen flex-col items-center justify-center px-4 pt-20"
    >
      <div className="mx-auto flex w-full max-w-5xl flex-col-reverse items-center gap-10 md:flex-row md:justify-between">
        <div className="max-w-xl text-center md:text-left">
          <p className="mb-3 text-sm font-medium uppercase tracking-[0.2em] text-[var(--accent)]">
            Chào mừng đến với portfolio của tôi
          </p>
          <h1 className="text-4xl font-extrabold leading-tight sm:text-5xl lg:text-6xl">
            Xin chào, tôi là{" "}
            <span className="text-gradient">{profile.name}</span>
          </h1>
          <p
            className="mt-4 h-8 text-lg font-medium text-[var(--text-muted)] sm:text-xl"
            aria-label={`Nghề nghiệp: ${profile.role}`}
          >
            <span aria-hidden="true">
              {typed}
              <span className="typing-caret" />
            </span>
          </p>
          <p className="mt-4 text-[var(--text-muted)]">{profile.shortBio}</p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3 md:justify-start">
            <a
              href="#projects"
              className="focus-ring rounded-xl bg-gradient-to-r from-[var(--primary)] to-[var(--accent)] px-6 py-3 font-semibold text-white shadow-lg shadow-[var(--primary)]/25 transition-transform hover:-translate-y-0.5 active:translate-y-0"
            >
              Xem dự án
            </a>
            <a
              href="#contact"
              className="focus-ring glass rounded-xl px-6 py-3 font-semibold transition-transform hover:-translate-y-0.5 active:translate-y-0"
            >
              Liên hệ
            </a>
            {hasCV ? (
              <a
                href={withBase(profile.cvUrl)}
                download
                className="focus-ring rounded-xl border border-[var(--card-border)] px-6 py-3 font-semibold text-[var(--text-muted)] transition-colors hover:text-[var(--text)]"
              >
                ⬇️ Tải CV
              </a>
            ) : (
              <button
                type="button"
                disabled
                title="Chưa có tệp CV — thêm tệp PDF vào public/ và cập nhật cvUrl trong src/config/profile.ts"
                className="cursor-not-allowed rounded-xl border border-dashed border-[var(--card-border)] px-6 py-3 font-semibold text-[var(--text-muted)] opacity-60"
              >
                ⬇️ Tải CV (chưa cấu hình)
              </button>
            )}
          </div>

          <ul
            className="mt-8 flex items-center justify-center gap-3 md:justify-start"
            aria-label="Mạng xã hội"
          >
            {profile.socials.map((s) => (
              <li key={s.label}>
                <a
                  href={s.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={s.label}
                  title={s.label}
                  className="focus-ring glass flex h-11 w-11 items-center justify-center rounded-full text-[var(--text-muted)] transition-all hover:-translate-y-1 hover:text-[var(--accent)]"
                >
                  <SocialIcon name={s.icon} />
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Ảnh đại diện */}
        <div className="relative shrink-0">
          <div
            aria-hidden="true"
            className="absolute -inset-4 rounded-full bg-gradient-to-tr from-[var(--primary)] to-[var(--accent)] opacity-30 blur-2xl"
          />
          <img
            src={withBase(profile.avatar)}
            alt={`Ảnh đại diện của ${profile.name}`}
            width={260}
            height={260}
            loading="eager"
            className="relative h-48 w-48 rounded-full border-2 border-[var(--card-border)] object-cover shadow-2xl sm:h-64 sm:w-64"
          />
        </div>
      </div>

      {/* Gợi ý cuộn xuống */}
      <a
        href="#about"
        aria-label="Cuộn xuống phần giới thiệu"
        className="focus-ring scroll-hint absolute bottom-6 left-1/2 -translate-x-1/2 text-[var(--text-muted)] hover:text-[var(--accent)]"
      >
        <svg
          width="28"
          height="28"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <path d="M12 5v14" />
          <path d="m19 12-7 7-7-7" />
        </svg>
      </a>
    </section>
  );
}
