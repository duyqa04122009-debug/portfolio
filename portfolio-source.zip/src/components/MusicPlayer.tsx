import { useEffect, useRef, useState } from "react";
import { profile } from "../config/profile";
import { withBase } from "../lib/paths";

function safeGet(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}
function safeSet(key: string, value: string) {
  try {
    localStorage.setItem(key, value);
  } catch {
    /* bỏ qua */
  }
}

/**
 * Trình phát nhạc nền:
 * - KHÔNG tự phát khi mở trang (tuân thủ chính sách autoplay của trình duyệt).
 * - Người dùng chủ động bấm "Bật nhạc"; có play/pause, thanh âm lượng.
 * - Ghi nhớ âm lượng; fade in/out nhẹ; âm lượng mặc định nhỏ (0.3).
 * - Nếu chưa cấu hình tệp nhạc => hiển thị trạng thái rõ ràng, không liên kết hỏng.
 */
export default function MusicPlayer() {
  const hasMusic = Boolean(profile.musicSrc);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fadeTimer = useRef<number | null>(null);

  const [open, setOpen] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [failed, setFailed] = useState(false);
  const [volume, setVolume] = useState(() => {
    const saved = Number(safeGet("pf-volume"));
    return Number.isFinite(saved) && saved > 0 && saved <= 1 ? saved : 0.3;
  });

  useEffect(() => {
    if (!hasMusic) return;
    const audio = new Audio(withBase(profile.musicSrc));
    audio.loop = true;
    audio.preload = "none"; // không tải trước khi người dùng cần
    audioRef.current = audio;
    return () => {
      audio.pause();
      audioRef.current = null;
    };
  }, [hasMusic]);

  useEffect(() => {
    safeSet("pf-volume", String(volume));
    const audio = audioRef.current;
    if (audio && playing) audio.volume = volume;
  }, [volume, playing]);

  function clearFade() {
    if (fadeTimer.current !== null) {
      window.clearInterval(fadeTimer.current);
      fadeTimer.current = null;
    }
  }

  function fadeTo(target: number, onDone?: () => void) {
    const audio = audioRef.current;
    if (!audio) return;
    clearFade();
    const step = (target - audio.volume) / 12;
    fadeTimer.current = window.setInterval(() => {
      const next = audio.volume + step;
      const done =
        (step >= 0 && next >= target) || (step < 0 && next <= target);
      audio.volume = done ? target : Math.min(1, Math.max(0, next));
      if (done) {
        clearFade();
        onDone?.();
      }
    }, 60);
  }

  async function play() {
    const audio = audioRef.current;
    if (!audio) return;
    try {
      audio.volume = 0;
      await audio.play(); // cần tương tác người dùng — đã có vì đây là handler click
      setFailed(false);
      setPlaying(true);
      fadeTo(volume);
    } catch {
      // Trình duyệt chặn hoặc tệp lỗi — báo rõ, không giả vờ đang phát
      setFailed(true);
      setPlaying(false);
    }
  }

  function pause() {
    const audio = audioRef.current;
    if (!audio) return;
    fadeTo(0, () => {
      audio.pause();
    });
    setPlaying(false);
  }

  return (
    <div className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2">
      {open && (
        <div className="glass w-64 rounded-2xl bg-[var(--bg-soft)]/90 p-4 shadow-2xl">
          <p className="text-sm font-semibold">🎵 {profile.musicTitle}</p>

          {!hasMusic ? (
            <p className="mt-2 text-xs leading-relaxed text-[var(--text-muted)]">
              Chưa cấu hình tệp nhạc. Đặt tệp nhạc có bản quyền hợp lệ vào thư
              mục <code>public/</code> rồi điền <code>musicSrc</code> trong{" "}
              <code>src/config/profile.ts</code>.
            </p>
          ) : (
            <>
              <div className="mt-3 flex items-center gap-3">
                <button
                  type="button"
                  onClick={playing ? pause : play}
                  className="focus-ring flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-r from-[var(--primary)] to-[var(--accent)] text-white shadow-lg"
                  aria-label={playing ? "Tạm dừng nhạc" : "Bật nhạc"}
                >
                  {playing ? "⏸" : "▶"}
                </button>
                <div className="flex-1">
                  <label
                    htmlFor="music-volume"
                    className="block text-xs text-[var(--text-muted)]"
                  >
                    Âm lượng: {Math.round(volume * 100)}%
                  </label>
                  <input
                    id="music-volume"
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={volume}
                    onChange={(e) => setVolume(Number(e.target.value))}
                    className="focus-ring w-full accent-[var(--accent)]"
                  />
                </div>
              </div>
              <p aria-live="polite" className="mt-2 text-xs text-[var(--text-muted)]">
                {failed
                  ? "⚠️ Không phát được nhạc. Kiểm tra lại đường dẫn tệp hoặc thử bấm phát lần nữa."
                  : playing
                  ? "Đang phát…"
                  : "Đã tạm dừng. Bấm ▶ để bật nhạc."}
              </p>
            </>
          )}
        </div>
      )}

      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-label={open ? "Đóng trình phát nhạc" : "Mở trình phát nhạc"}
        title="Nhạc nền"
        className={`focus-ring glass flex h-12 w-12 items-center justify-center rounded-full shadow-xl transition-transform hover:-translate-y-0.5 ${
          playing ? "text-[var(--accent)]" : "text-[var(--text-muted)]"
        }`}
      >
        <span aria-hidden="true" className="text-xl">
          {playing ? "🎶" : "🎵"}
        </span>
      </button>
    </div>
  );
}
