import { profile } from "../config/profile";
import Reveal from "./Reveal";

export default function About() {
  const hasStats = profile.stats.length > 0;
  const hasSample = profile.stats.some((s) => s.isSample);

  return (
    <section id="about" className="mx-auto max-w-6xl px-4 py-24">
      <Reveal>
        <h2 className="text-center text-3xl font-bold sm:text-4xl">
          Giới <span className="text-gradient">thiệu</span>
        </h2>
        <p className="mx-auto mt-3 max-w-xl text-center text-[var(--text-muted)]">
          Câu chuyện ngắn về bản thân, định hướng và sở thích của tôi.
        </p>
      </Reveal>

      <div className="mt-12 grid gap-10 md:grid-cols-2">
        <Reveal>
          <div className="space-y-4 leading-relaxed text-[var(--text-muted)]">
            {profile.story.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
            <p className="font-medium text-[var(--text)]">
              📍 {profile.location}
            </p>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <div className="grid grid-cols-2 gap-4">
            {profile.infoCards.map((c) => (
              <div
                key={c.title}
                className="glass rounded-2xl p-5 transition-transform hover:-translate-y-1"
              >
                <div className="text-2xl" aria-hidden="true">
                  {c.icon}
                </div>
                <h3 className="mt-2 font-semibold">{c.title}</h3>
                <p className="mt-1 text-sm text-[var(--text-muted)]">
                  {c.value}
                </p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>

      {hasStats && (
        <Reveal delay={150}>
          <div className="mt-12">
            <div className="glass grid grid-cols-1 gap-6 rounded-2xl p-8 sm:grid-cols-3">
              {profile.stats.map((s) => (
                <div key={s.label} className="text-center">
                  <div className="text-gradient text-4xl font-extrabold">
                    {s.value}
                  </div>
                  <div className="mt-1 text-sm text-[var(--text-muted)]">
                    {s.label}
                    {s.isSample && " *"}
                  </div>
                </div>
              ))}
            </div>
            {hasSample && (
              <p className="mt-3 text-center text-xs text-[var(--text-muted)]">
                * Số liệu minh họa từ dữ liệu mẫu — thay bằng số liệu thật trong{" "}
                <code>src/config/profile.ts</code>.
              </p>
            )}
          </div>
        </Reveal>
      )}
    </section>
  );
}
