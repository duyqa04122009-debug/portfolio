import { useEffect, useRef, useState } from "react";
import { profile } from "../config/profile";
import { useSettings } from "../context/SettingsContext";

export const SECTIONS = [
  { id: "home", label: "Trang chủ" },
  { id: "about", label: "Giới thiệu" },
  { id: "skills", label: "Kỹ năng" },
  { id: "projects", label: "Dự án" },
  { id: "journey", label: "Hành trình" },
  { id: "contact", label: "Liên hệ" },
];

export default function Navbar() {
  const { theme, toggleTheme, effectsOn, toggleEffects } = useSettings();
  const [scrolled, setScrolled] = useState(false);
  const [active, setActive] = useState("home");
  const [menuOpen, setMenuOpen] = useState(false);
  const menuButtonRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  // Đổi nền navbar khi cuộn
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Đánh dấu mục đang xem
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting) setActive(e.target.id);
        }
      },
      { rootMargin: "-40% 0px -55% 0px" }
    );
    SECTIONS.forEach(({ id }) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, []);

  // Đóng menu mobile bằng Escape + trả focus về nút
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMenuOpen(false);
        menuButtonRef.current?.focus();
      }
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [menuOpen]);

  const linkClass = (id: string) =>
    `focus-ring rounded-md px-3 py-2 text-sm font-medium transition-colors ${
      active === id
        ? "text-[var(--accent)]"
        : "text-[var(--text-muted)] hover:text-[var(--text)]"
    }`;

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-all duration-300 ${
        scrolled ? "glass shadow-lg shadow-black/10" : "bg-transparent"
      }`}
    >
      <nav
        aria-label="Điều hướng chính"
        className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3"
      >
        <a
          href="#home"
          className="focus-ring text-lg font-bold tracking-tight"
          aria-label="Về đầu trang"
        >
          <span className="text-gradient">{profile.name}</span>
        </a>

        {/* Desktop */}
        <div className="hidden items-center gap-1 md:flex">
          {SECTIONS.map((s) => (
            <a
              key={s.id}
              href={`#${s.id}`}
              className={linkClass(s.id)}
              aria-current={active === s.id ? "true" : undefined}
            >
              {s.label}
            </a>
          ))}
          <div className="mx-2 h-5 w-px bg-[var(--card-border)]" />
          <button
            type="button"
            onClick={toggleEffects}
            className="focus-ring rounded-md px-2.5 py-2 text-sm text-[var(--text-muted)] hover:text-[var(--text)]"
            title={effectsOn ? "Tắt hiệu ứng 3D" : "Bật hiệu ứng 3D"}
            aria-pressed={effectsOn}
          >
            <span aria-hidden="true">{effectsOn ? "✨" : "💤"}</span>
            <span className="sr-only">
              {effectsOn ? "Tắt hiệu ứng" : "Bật hiệu ứng"}
            </span>
          </button>
          <button
            type="button"
            onClick={toggleTheme}
            className="focus-ring rounded-md px-2.5 py-2 text-sm text-[var(--text-muted)] hover:text-[var(--text)]"
            title={theme === "dark" ? "Chuyển chế độ sáng" : "Chuyển chế độ tối"}
          >
            <span aria-hidden="true">{theme === "dark" ? "☀️" : "🌙"}</span>
            <span className="sr-only">
              {theme === "dark" ? "Chế độ sáng" : "Chế độ tối"}
            </span>
          </button>
        </div>

        {/* Nút mở menu mobile */}
        <button
          ref={menuButtonRef}
          type="button"
          className="focus-ring rounded-md p-2 md:hidden"
          aria-expanded={menuOpen}
          aria-controls="mobile-menu"
          aria-label={menuOpen ? "Đóng menu" : "Mở menu"}
          onClick={() => setMenuOpen((o) => !o)}
        >
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            aria-hidden="true"
          >
            {menuOpen ? (
              <>
                <path d="M6 6l12 12" />
                <path d="M18 6L6 18" />
              </>
            ) : (
              <>
                <path d="M4 7h16" />
                <path d="M4 12h16" />
                <path d="M4 17h16" />
              </>
            )}
          </svg>
        </button>
      </nav>

      {/* Menu mobile */}
      {menuOpen && (
        <div ref={menuRef} id="mobile-menu" className="glass md:hidden">
          <div className="flex flex-col px-4 pb-4">
            {SECTIONS.map((s) => (
              <a
                key={s.id}
                href={`#${s.id}`}
                className={linkClass(s.id)}
                aria-current={active === s.id ? "true" : undefined}
                onClick={() => setMenuOpen(false)}
              >
                {s.label}
              </a>
            ))}
            <div className="mt-2 flex gap-2 border-t border-[var(--card-border)] pt-3">
              <button
                type="button"
                onClick={toggleEffects}
                className="focus-ring glass rounded-md px-3 py-2 text-sm"
                aria-pressed={effectsOn}
              >
                {effectsOn ? "✨ Tắt hiệu ứng" : "💤 Bật hiệu ứng"}
              </button>
              <button
                type="button"
                onClick={toggleTheme}
                className="focus-ring glass rounded-md px-3 py-2 text-sm"
              >
                {theme === "dark" ? "☀️ Chế độ sáng" : "🌙 Chế độ tối"}
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
