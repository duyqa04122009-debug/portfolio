import { profile } from "../config/profile";
import { SECTIONS } from "./Navbar";
import { SocialIcon } from "./Icons";

export default function Footer() {
  const year = new Date().getFullYear(); // năm bản quyền tự động

  return (
    <footer className="border-t border-[var(--card-border)] px-4 py-12">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-8 md:flex-row md:items-start md:justify-between">
        <div className="text-center md:text-left">
          <p className="text-lg font-bold">
            <span className="text-gradient">{profile.name}</span>
          </p>
          <p className="mt-1 max-w-xs text-sm text-[var(--text-muted)]">
            {profile.role} — {profile.location}
          </p>
        </div>

        <nav aria-label="Liên kết nhanh">
          <h3 className="text-center text-sm font-semibold uppercase tracking-wide text-[var(--text-muted)] md:text-left">
            Liên kết nhanh
          </h3>
          <ul className="mt-3 grid grid-cols-3 gap-x-6 gap-y-2 text-sm">
            {SECTIONS.map((s) => (
              <li key={s.id}>
                <a
                  href={`#${s.id}`}
                  className="focus-ring text-[var(--text-muted)] hover:text-[var(--accent)]"
                >
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex flex-col items-center gap-4 md:items-end">
          <ul className="flex gap-2" aria-label="Mạng xã hội">
            {profile.socials.map((s) => (
              <li key={s.label}>
                <a
                  href={s.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={s.label}
                  title={s.label}
                  className="focus-ring glass flex h-10 w-10 items-center justify-center rounded-full text-[var(--text-muted)] transition-all hover:-translate-y-1 hover:text-[var(--accent)]"
                >
                  <SocialIcon name={s.icon} />
                </a>
              </li>
            ))}
          </ul>
          <button
            type="button"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="focus-ring glass rounded-xl px-4 py-2 text-sm font-medium transition-transform hover:-translate-y-0.5"
          >
            ↑ Về đầu trang
          </button>
        </div>
      </div>

      <p className="mt-10 text-center text-xs text-[var(--text-muted)]">
        © {year} {profile.name}. Website xây dựng bằng React, TypeScript,
        Tailwind CSS và Three.js.
      </p>
    </footer>
  );
}
