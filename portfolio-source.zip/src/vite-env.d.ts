/// <reference types="vite/client" />

interface ImportMetaEnv {
  /** Endpoint nhận dữ liệu form liên hệ (tùy chọn) */
  readonly VITE_CONTACT_ENDPOINT?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
