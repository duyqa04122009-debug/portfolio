import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

type Theme = "dark" | "light";

interface Settings {
  theme: Theme;
  toggleTheme: () => void;
  /** Hiệu ứng 3D/chuyển động đang bật? */
  effectsOn: boolean;
  toggleEffects: () => void;
  /** Người dùng yêu cầu giảm chuyển động (hệ điều hành) */
  reducedMotion: boolean;
}

const SettingsContext = createContext<Settings | null>(null);

function safeGet(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}
function safeSet(key: string, value: string) {
  try {
    localStorage.setItem(key, value);
  } catch {
    /* bỏ qua nếu trình duyệt chặn */
  }
}

export function SettingsProvider({ children }: { children: ReactNode }) {
  const prefersReduced =
    typeof window !== "undefined" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  const [theme, setTheme] = useState<Theme>(() =>
    safeGet("pf-theme") === "light" ? "light" : "dark"
  );
  const [effectsOn, setEffectsOn] = useState<boolean>(() => {
    const saved = safeGet("pf-effects");
    if (saved !== null) return saved === "on";
    return !prefersReduced; // tôn trọng prefers-reduced-motion
  });
  const [reducedMotion, setReducedMotion] = useState(prefersReduced);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onChange = () => setReducedMotion(mq.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("light", theme === "light");
    safeSet("pf-theme", theme);
  }, [theme]);

  useEffect(() => {
    safeSet("pf-effects", effectsOn ? "on" : "off");
  }, [effectsOn]);

  const toggleTheme = useCallback(
    () => setTheme((t) => (t === "dark" ? "light" : "dark")),
    []
  );
  const toggleEffects = useCallback(() => setEffectsOn((e) => !e), []);

  const value = useMemo(
    () => ({ theme, toggleTheme, effectsOn, toggleEffects, reducedMotion }),
    [theme, toggleTheme, effectsOn, toggleEffects, reducedMotion]
  );

  return (
    <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>
  );
}

export function useSettings(): Settings {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error("useSettings phải dùng bên trong SettingsProvider");
  return ctx;
}
