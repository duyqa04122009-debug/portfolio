import { Suspense, lazy, useEffect } from "react";
import { SettingsProvider, useSettings } from "./context/SettingsContext";
import { profile } from "./config/profile";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Skills from "./components/Skills";
import Projects from "./components/Projects";
import Journey from "./components/Journey";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import MusicPlayer from "./components/MusicPlayer";

// Lazy-load phần 3D để không chặn nội dung chính
const Background3D = lazy(() => import("./components/Background3D"));

function AppInner() {
  const { effectsOn } = useSettings();

  // Đồng bộ tiêu đề trang với tệp cấu hình
  useEffect(() => {
    document.title = `${profile.name} — Portfolio`;
  }, []);

  return (
    <>
      {/* Nền 3D trang trí: aria-hidden, không chặn thao tác, có fallback tĩnh */}
      {effectsOn ? (
        <Suspense fallback={<div aria-hidden="true" className="static-bg fixed inset-0 -z-10" />}>
          <Background3D />
        </Suspense>
      ) : (
        <div aria-hidden="true" className="static-bg fixed inset-0 -z-10" />
      )}

      <Navbar />
      <main>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Journey />
        <Contact />
      </main>
      <Footer />
      <MusicPlayer />
    </>
  );
}

export default function App() {
  return (
    <SettingsProvider>
      <AppInner />
    </SettingsProvider>
  );
}
