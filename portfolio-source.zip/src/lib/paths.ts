/**
 * Chuyển đường dẫn tài nguyên trong public/ (ví dụ "/avatar.png")
 * thành đường dẫn đúng theo base của website.
 * Nhờ đó website chạy được cả ở gốc tên miền lẫn thư mục con
 * (ví dụ GitHub Pages: https://ten-ban.github.io/portfolio/).
 */
export function withBase(path: string): string {
  if (!path) return path;
  if (/^https?:\/\//.test(path)) return path; // URL tuyệt đối giữ nguyên
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  return `${base}/${path.replace(/^\//, "")}`;
}
