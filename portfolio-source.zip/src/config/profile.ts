/**
 * ============================================================
 *  TỆP CẤU HÌNH DUY NHẤT — THAY TOÀN BỘ THÔNG TIN CÁ NHÂN Ở ĐÂY
 * ============================================================
 *  LƯU Ý: Toàn bộ dữ liệu dưới đây là DỮ LIỆU MẪU minh họa.
 *  Hãy thay bằng thông tin thật của bạn trước khi công khai website.
 */

export interface SocialLink {
  label: string;
  url: string;
  icon: "github" | "facebook" | "linkedin" | "instagram" | "email";
}

export interface Stat {
  value: string;
  label: string;
  /** true = số liệu minh họa, sẽ hiển thị ghi chú "(minh họa)" */
  isSample: boolean;
}

export interface SkillItem {
  name: string;
  /** Nhãn kinh nghiệm tùy chọn, ví dụ "2 năm", "Thường dùng". Để trống nếu không muốn hiển thị. */
  levelLabel?: string;
  icon: string; // emoji hoặc ký tự
}

export interface SkillGroup {
  title: string;
  items: SkillItem[];
}

export interface Project {
  id: string;
  title: string;
  description: string;
  details: string;
  category: string;
  tech: string[];
  /** Đường dẫn ảnh trong /public, ví dụ "/projects/web-app.jpg". Để trống sẽ dùng nền gradient. */
  image?: string;
  /** Chỉ hiển thị nút khi có URL hợp lệ (bắt đầu bằng http) */
  demoUrl?: string;
  sourceUrl?: string;
}

export interface TimelineItem {
  time: string;
  title: string;
  place: string;
  description: string;
  type: "education" | "work" | "milestone";
}

export const profile = {
  // ---------- 1. THÔNG TIN CƠ BẢN ----------
  name: "Nguyễn Minh An",
  role: "Lập trình viên Front-end",
  /** Các cụm từ chạy hiệu ứng gõ chữ ở trang chủ */
  typingPhrases: [
    "Lập trình viên Front-end",
    "Yêu thích UI/UX",
    "Đam mê trải nghiệm 3D trên web",
  ],
  shortBio:
    "Mình là một lập trình viên trẻ tại TP. Hồ Chí Minh, yêu thích xây dựng giao diện web đẹp, mượt và dễ dùng. Mình tin rằng sản phẩm tốt bắt đầu từ sự tỉ mỉ trong từng chi tiết nhỏ.",
  story: [
    "Mình bắt đầu học lập trình từ những năm cấp ba với niềm tò mò về cách các trang web hoạt động. Từ đó, hành trình khám phá công nghệ của mình chưa bao giờ dừng lại.",
    "Hiện tại mình tập trung vào hệ sinh thái React và các trải nghiệm tương tác 3D trên web. Ngoài giờ code, mình thích chụp ảnh, đọc sách thiết kế và đi cà phê khám phá thành phố.",
  ],
  email: "minhan.dev@example.com",
  location: "TP. Hồ Chí Minh, Việt Nam",
  /** Đường dẫn ảnh đại diện trong /public. Thay bằng ảnh của bạn: đặt ảnh vào public/ rồi sửa đường dẫn. */
  avatar: "/avatar.png",
  /**
   * Đường dẫn tệp CV (PDF) trong /public, ví dụ "/cv-nguyen-minh-an.pdf".
   * Để trống "" => nút "Tải CV" sẽ bị vô hiệu hóa kèm giải thích.
   */
  cvUrl: "",

  // ---------- MẠNG XÃ HỘI ----------
  socials: [
    { label: "GitHub", url: "https://github.com/example", icon: "github" },
    { label: "Facebook", url: "https://facebook.com/example", icon: "facebook" },
    { label: "LinkedIn", url: "https://linkedin.com/in/example", icon: "linkedin" },
    { label: "Instagram", url: "https://instagram.com/example", icon: "instagram" },
  ] as SocialLink[],

  // ---------- THẺ THÔNG TIN (phần Giới thiệu) ----------
  infoCards: [
    { icon: "🎓", title: "Học vấn", value: "Cử nhân CNTT (mẫu)" },
    { icon: "💼", title: "Định hướng", value: "Front-end & Creative Web" },
    { icon: "🌏", title: "Ngôn ngữ", value: "Tiếng Việt, Tiếng Anh" },
    { icon: "☕", title: "Sở thích", value: "Nhiếp ảnh, đọc sách, cà phê" },
  ],

  /**
   * SỐ LIỆU THÀNH TÍCH — isSample: true nghĩa là dữ liệu minh họa,
   * website sẽ tự ghi chú rõ "(số liệu minh họa)". Đặt isSample: false
   * CHỈ KHI đó là số liệu thật của bạn. Xóa hết phần tử => ẩn toàn bộ khối.
   */
  stats: [
    { value: "10+", label: "Dự án cá nhân", isSample: true },
    { value: "2", label: "Năm học và thực hành", isSample: true },
    { value: "5", label: "Công nghệ thường dùng", isSample: true },
  ] as Stat[],

  // ---------- 2. KỸ NĂNG ----------
  skillGroups: [
    {
      title: "Chuyên môn",
      items: [
        { name: "HTML / CSS", levelLabel: "Thường dùng", icon: "🧱" },
        { name: "JavaScript / TypeScript", levelLabel: "Thường dùng", icon: "⚡" },
        { name: "React", levelLabel: "Thường dùng", icon: "⚛️" },
        { name: "Three.js", levelLabel: "Đang học sâu", icon: "🧊" },
      ],
    },
    {
      title: "Công cụ",
      items: [
        { name: "Git & GitHub", icon: "🔧" },
        { name: "Figma", icon: "🎨" },
        { name: "Vite", icon: "⚙️" },
        { name: "VS Code", icon: "💻" },
      ],
    },
    {
      title: "Kỹ năng mềm",
      items: [
        { name: "Làm việc nhóm", icon: "🤝" },
        { name: "Giao tiếp", icon: "💬" },
        { name: "Tự học", icon: "📚" },
        { name: "Quản lý thời gian", icon: "⏱️" },
      ],
    },
  ] as SkillGroup[],

  // ---------- 3. DỰ ÁN (dữ liệu mẫu) ----------
  projectCategories: ["Tất cả", "Web App", "Landing Page", "Thử nghiệm 3D"],
  projects: [
    {
      id: "p1",
      title: "Ứng dụng quản lý công việc",
      description: "Web app quản lý công việc cá nhân với kéo-thả và nhắc việc.",
      details:
        "Dự án mẫu: ứng dụng to-do nâng cao cho phép tạo bảng, kéo thả thẻ công việc, gắn nhãn màu và lưu dữ liệu cục bộ. Tập trung vào trải nghiệm mượt và phím tắt tiện dụng.",
      category: "Web App",
      tech: ["React", "TypeScript", "Tailwind CSS"],
      demoUrl: "",
      sourceUrl: "https://github.com/example/task-app",
    },
    {
      id: "p2",
      title: "Landing page quán cà phê",
      description: "Trang giới thiệu quán cà phê với hiệu ứng cuộn thị sai nhẹ.",
      details:
        "Dự án mẫu: landing page một trang cho quán cà phê, chú trọng typography, hình ảnh và tốc độ tải. Điểm nhấn là menu tương tác và bản đồ chỉ đường.",
      category: "Landing Page",
      tech: ["HTML", "CSS", "JavaScript"],
      demoUrl: "",
      sourceUrl: "",
    },
    {
      id: "p3",
      title: "Thiên hà hạt 3D",
      description: "Thử nghiệm Three.js: mô phỏng thiên hà bằng hệ thống hạt.",
      details:
        "Dự án mẫu: cảnh 3D gồm hàng chục nghìn hạt tạo hình xoắn ốc thiên hà, điều khiển bằng chuột và tùy chỉnh màu theo thời gian thực. Bài học lớn về tối ưu hiệu năng WebGL.",
      category: "Thử nghiệm 3D",
      tech: ["Three.js", "GLSL", "Vite"],
      demoUrl: "https://example.com/galaxy-demo",
      sourceUrl: "https://github.com/example/galaxy",
    },
    {
      id: "p4",
      title: "Trang tra cứu thời tiết",
      description: "Web app xem thời tiết theo thành phố với biểu đồ nhiệt độ.",
      details:
        "Dự án mẫu: ứng dụng gọi API thời tiết, hiển thị dự báo 7 ngày bằng biểu đồ, hỗ trợ tìm kiếm thành phố Việt Nam và lưu địa điểm yêu thích.",
      category: "Web App",
      tech: ["React", "Chart.js", "REST API"],
      demoUrl: "",
      sourceUrl: "",
    },
  ] as Project[],

  // ---------- 4. HÀNH TRÌNH (dữ liệu mẫu) ----------
  timeline: [
    {
      time: "2021",
      title: "Bắt đầu học lập trình",
      place: "Tự học",
      description: "Làm quen HTML, CSS, JavaScript qua các khóa học trực tuyến và dự án nhỏ.",
      type: "milestone",
    },
    {
      time: "2022 — nay",
      title: "Sinh viên Công nghệ thông tin",
      place: "Trường Đại học (mẫu)",
      description: "Theo học chuyên ngành Kỹ thuật phần mềm, tham gia CLB lập trình của trường.",
      type: "education",
    },
    {
      time: "2023",
      title: "Dự án web đầu tiên cho khách thật",
      place: "Freelance",
      description: "Thiết kế và xây dựng landing page cho một quán cà phê địa phương.",
      type: "work",
    },
    {
      time: "2024",
      title: "Khám phá web 3D",
      place: "Dự án cá nhân",
      description: "Bắt đầu học Three.js và React Three Fiber, xây dựng các thử nghiệm tương tác.",
      type: "milestone",
    },
  ] as TimelineItem[],

  // ---------- 5. NHẠC NỀN ----------
  /**
   * Đặt tệp nhạc (mp3/ogg có bản quyền hợp lệ của bạn) vào thư mục public/
   * rồi điền đường dẫn, ví dụ: "/music/lofi-chill.mp3".
   * Để trống "" => trình phát hiển thị trạng thái "chưa cấu hình", không dùng liên kết hỏng.
   */
  musicSrc: "",
  musicTitle: "Nhạc nền không lời",
};

export type Profile = typeof profile;
